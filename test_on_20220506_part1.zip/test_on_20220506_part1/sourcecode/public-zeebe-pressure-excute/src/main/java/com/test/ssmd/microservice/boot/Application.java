package com.test.ssmd.microservice.boot;

import io.camunda.zeebe.spring.client.EnableZeebeClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 描述: 程序主入口
 *
 * @author yimiluo
 * @create 2022-01-07 3:10 下午
 */
@Slf4j
@SpringBootApplication
@EnableZeebeClient
public class Application {
    public static void main(String[] args) {
        log.info("application start running...");
        SpringApplication.run(Application.class, args);
    }
}
