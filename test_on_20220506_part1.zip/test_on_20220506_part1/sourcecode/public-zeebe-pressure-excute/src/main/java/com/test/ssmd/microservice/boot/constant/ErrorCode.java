package com.test.ssmd.microservice.boot.constant;

import com.test.ssmd.boot.exception.IErrorCode;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 错误码定义
 */
@Getter
@AllArgsConstructor
public enum ErrorCode implements IErrorCode {

    MISSING_REQUIRED_PARAMS("PBWF1000", "缺少必要参数"),
    INVALID_PARAMS("PBWF1001", "参数非法"),
    DUPLICATED_ITEMS("PBWF2001", "资源重复"),
    ITEM_NOT_FOUND("PBWF2002", "资源不存在"),
    INVALID_STATE("PBWF3001", "状态非法"),
    DUPLICATED_OPERATION("PBWF4001", "重复操作"),

    INSTANCE_NOT_FOUND("PBWF5001", "旧Zeebe无对应实例可操作");

    private String code;
    private String message;

}
