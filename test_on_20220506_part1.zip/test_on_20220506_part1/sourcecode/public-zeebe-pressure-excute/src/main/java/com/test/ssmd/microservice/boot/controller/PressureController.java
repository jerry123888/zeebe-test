package com.test.ssmd.microservice.boot.controller;

import com.test.ssmd.microservice.boot.dto.req.CreateInstanceReq;
import com.test.ssmd.microservice.boot.dto.req.SetVariablesReq;
import com.test.ssmd.microservice.boot.dto.resp.CreateInstanceResp;
import com.test.ssmd.microservice.boot.dto.resp.SetVariablesResp;
import com.test.ssmd.microservice.boot.service.PressureService;
import io.camunda.zeebe.client.api.response.DeploymentEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

/**
 * 描述: 脚手架创建的Controller
 *
 * @author yimiluo
 * @create 2022-01-07 3:10 下午
 */
@RestController
public class PressureController {

    @Autowired
    private PressureService pressureService;

    @GetMapping("hello")
    public boolean hello() {
        return true;
    }

    @PostMapping("createInstance")
    public CreateInstanceResp createInstance(@RequestBody CreateInstanceReq createInstanceReq) {
        return pressureService.createInstance(createInstanceReq);
    }

    @PostMapping("deployProcess")
    public DeploymentEvent deployProcess(MultipartFile file) {
        return pressureService.deployProcess(file);
    }

    @PostMapping("setVariables")
    public SetVariablesResp setVariables(@RequestBody SetVariablesReq setVariablesReq) {
        return pressureService.setVariables(setVariablesReq.getElementId(), setVariablesReq.getVariables());
    }

}
