package com.test.ssmd.microservice.boot.dto.req;

import java.util.Map;
import lombok.Data;

@Data
public class CreateInstanceReq {

    public static final Integer DEFAULT_VERSION = -1;

    private String processId;

    private Integer version = DEFAULT_VERSION;

    private Map<String, Object> variables;
}
