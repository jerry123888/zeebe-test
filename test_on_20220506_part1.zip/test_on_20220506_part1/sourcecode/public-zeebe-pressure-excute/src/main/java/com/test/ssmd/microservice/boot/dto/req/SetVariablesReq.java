package com.test.ssmd.microservice.boot.dto.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Map;
import lombok.Data;

/**
 * @author lancetang
 * @date 2020/9/24 16:00
 * @description 说明文件
 */
@Data
public class SetVariablesReq {

    private long elementId;

    private Map<String, Object> variables;
}
