package com.test.ssmd.microservice.boot.dto.resp;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CreateInstanceResp {

    private String processId;

    private long instanceId;
}
