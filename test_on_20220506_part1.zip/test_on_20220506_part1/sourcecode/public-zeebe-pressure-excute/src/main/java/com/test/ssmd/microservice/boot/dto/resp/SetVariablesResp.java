package com.test.ssmd.microservice.boot.dto.resp;

import lombok.Data;

/**
 * 描述: TODO...
 *
 * @author yimiluo
 * @create 2022-01-14 2:33 下午
 */
@Data
public class SetVariablesResp {
    private Long key;
}
