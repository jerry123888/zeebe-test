package com.test.ssmd.microservice.boot.entity;

import lombok.Data;

@Data
public class BpmnResource {
    private String xmlStr;
    private String resourceName;
}
