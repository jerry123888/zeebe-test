package com.test.ssmd.microservice.boot.jobworker;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.ZeebeWorker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 描述: 消费的 worker
 *
 * @author yimiluo
 * @create 2022-01-07 3:24 下午
 */
@Slf4j
@Component
public class PressureJob {

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll1")
    public void handlePressureJob1(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(ran);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        log.info("testzeebefor137:job1 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll2")
    public void handlePressureJob2(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(ran);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        log.info("testzeebefor137:job2 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll3")
    public void handlePressureJob3(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job3 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll4")
    public void handlePressureJob4(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job4 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll5")
    public void handlePressureJob5(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job5 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll6")
    public void handlePressureJob6(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job6 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll7")
    public void handlePressureJob7(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job7 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll8")
    public void handlePressureJob8(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job8 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll9")
    public void handlePressureJob9(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job9 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll10")
    public void handlePressureJob10(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job10 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll11")
    public void handlePressureJob11(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job11 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll12")
    public void handlePressureJob12(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job12 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll13")
    public void handlePressureJob13(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job13 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll14")
    public void handlePressureJob14(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job14 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll15")
    public void handlePressureJob15(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job15 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll16")
    public void handlePressureJob16(final JobClient client, final ActivatedJob job) {
		int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job16 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll17")
    public void handlePressureJob17(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
		client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job17 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll18")
    public void handlePressureJob18(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job18 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll19")
    public void handlePressureJob19(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } 
       client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job19 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll20")
    public void handlePressureJob20(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job20 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll21")
    public void handlePressureJob21(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job21 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll22")
    public void handlePressureJob22(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job22 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll23")
    public void handlePressureJob23(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        } 
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job23 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll24")
    public void handlePressureJob24(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job24 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll25")
    public void handlePressureJob25(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job25 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll26")
    public void handlePressureJob26(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job26 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll27")
    public void handlePressureJob27(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job27 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll28")
    public void handlePressureJob28(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job28 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll29")
    public void handlePressureJob29(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        //log.info("testzeebefor137:job29 is end，jobId = {}", job.getKey());
    }

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.IvanyeTestPoll30")
    public void handlePressureJob30(final JobClient client, final ActivatedJob job) {
        int max = 5;
        int min = 1;
        int ran2 = (int) (Math.random() * (max - min) + min);
        try {
            Thread.sleep(1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
        log.info("testzeebefor137:job30 is end，jobId = {}", job.getKey());
    }
}
