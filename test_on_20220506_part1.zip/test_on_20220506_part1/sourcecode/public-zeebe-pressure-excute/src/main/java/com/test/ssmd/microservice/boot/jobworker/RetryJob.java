package com.test.ssmd.microservice.boot.jobworker;

import io.camunda.zeebe.client.api.response.ActivatedJob;
import io.camunda.zeebe.client.api.worker.JobClient;
import io.camunda.zeebe.spring.client.annotation.ZeebeWorker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 描述: TODO...
 *
 * @author yimiluo
 * @create 2022-01-12 9:47 下午
 */
@Slf4j
@Component
public class RetryJob {

    @ZeebeWorker(type = "public-service-zeebe-pressure-execute.RetryJob")
    public void handleRetryJob(final JobClient client, final ActivatedJob job) {
        client.newCompleteCommand(job.getKey())
                .send()
                .exceptionally(throwable -> {
                    throw new RuntimeException("Could not complete job " + job, throwable);
                });
    }
}
