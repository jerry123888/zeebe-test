package com.test.ssmd.microservice.boot.manager;

import com.google.common.base.Strings;
import com.test.ssmd.boot.exception.BusinessException;
import com.test.ssmd.boot.exception.SystemExcetpion;
import com.test.ssmd.microservice.boot.constant.ErrorCode;
import com.test.ssmd.microservice.boot.entity.BpmnResource;
import io.camunda.zeebe.client.ZeebeClient;
import io.camunda.zeebe.client.api.command.CreateProcessInstanceCommandStep1.CreateProcessInstanceCommandStep2;
import io.camunda.zeebe.client.api.command.CreateProcessInstanceCommandStep1.CreateProcessInstanceCommandStep3;
import io.camunda.zeebe.client.api.response.DeploymentEvent;
import io.camunda.zeebe.client.api.response.ProcessInstanceEvent;
import io.camunda.zeebe.client.api.response.SetVariablesResponse;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * 描述: TODO...
 *
 * @author yimiluo
 * @create 2022-01-07 3:10 下午
 */
@Slf4j
@Component
public class ZeebeManager {

    @Resource
    private ZeebeClient zeebeClient;

    public static final Integer DEFAULT_VERSION = -1;

    /**
     * 创建实例
     * @param processId 流程ID
     * @param variables 流程入参
     * @param version 流程版本号
     * @return 创建完的流程相关信息，失败则抛异常
     */
    public ProcessInstanceEvent sendZeebeCreateInstanceCmd(String processId, Map<String, Object> variables,
            Integer version) {
        CreateProcessInstanceCommandStep2 step2 = zeebeClient.newCreateInstanceCommand()
                .bpmnProcessId(processId);
        CreateProcessInstanceCommandStep3 step3 = null;
        if (!DEFAULT_VERSION.equals(version)) {
            step3 = step2.version(version);
        } else {
            step3 = step2.latestVersion();
        }
        if (variables != null) {
            step3 = step3.variables(variables);
        }
        try {
            return step3.send().get();
        } catch (InterruptedException | ExecutionException e) {
            log.error("get createInstance result error", e);
            throw new SystemExcetpion(Strings.lenientFormat("get createInstance result error: %s", e.getMessage()));
        }
    }

    /**
     * 发布流程图到 Zeebe
     * @param bpmnResource 流程图资源（包括bpmn图数据和资源名）
     * @return 流程图对象，发布失败则抛异常
     */
    public DeploymentEvent sendZeebeDeployBpmnCmd(BpmnResource bpmnResource) {
        try {
            return zeebeClient.newDeployCommand()
                    .addResourceStringUtf8(bpmnResource.getXmlStr(), bpmnResource.getResourceName())
                    .send()
                    .get();
        } catch (InterruptedException | ExecutionException e) {
            log.error("error when deploy bpmn resource to zeebe", e);
            throw new SystemExcetpion(Strings.lenientFormat("发布流程图到zeebe出错：%s", e.getMessage()));
        }
    }

    /**
     * 设置变量
     * @param elementId jobId
     * @param variables 流程变量
     * @return 返回
     */
    public SetVariablesResponse setVariables(long elementId, Map<String, Object> variables) {
        try {
            return zeebeClient
                    .newSetVariablesCommand(elementId)
                    .variables(variables)
                    .send()
                    .get();
        } catch (InterruptedException | ExecutionException e) {
            if (e.getCause() instanceof StatusRuntimeException) {
                StatusRuntimeException statusRuntimeException = (StatusRuntimeException) e.getCause();
                Status status = statusRuntimeException.getStatus();
                if (status.getCode() == Status.Code.NOT_FOUND) {
                    throw new BusinessException(ErrorCode.INVALID_STATE.getCode(),
                            String.format("实例=%d已完成，不可以设置流程变量", elementId));
                }
            }
            String errorMsg = String.format("实例%s设置流程变量出错", elementId);
            log.error(errorMsg, e);
            throw new SystemExcetpion(errorMsg);
        }
    }
}
