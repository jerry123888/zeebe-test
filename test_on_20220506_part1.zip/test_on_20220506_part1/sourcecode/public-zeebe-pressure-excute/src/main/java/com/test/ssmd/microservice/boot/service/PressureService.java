package com.test.ssmd.microservice.boot.service;

import com.test.ssmd.microservice.boot.dto.req.CreateInstanceReq;
import com.test.ssmd.microservice.boot.dto.resp.CreateInstanceResp;
import com.test.ssmd.microservice.boot.dto.resp.SetVariablesResp;
import io.camunda.zeebe.client.api.response.DeploymentEvent;
import java.util.Map;
import org.springframework.web.multipart.MultipartFile;

/**
 * 描述: 压测服务类
 *
 * @author yimiluo
 * @create 2022-01-07 3:10 下午
 */
public interface PressureService {

    /**
     * 创建实例
     * @param createInstanceReq 创建实例数据对象
     * @return 返回创建完的实例ID和流程ID
     */
    CreateInstanceResp createInstance(CreateInstanceReq createInstanceReq);

    /**
     * 创建流程
     * @param file 流程文件
     * @return 返回是否创建成功
     */
    DeploymentEvent deployProcess(MultipartFile file);


    /**
     * 设置流程变量
     * @param elementId 流程ID
     * @param variables 变量值
     */
    SetVariablesResp setVariables(long elementId, Map<String, Object> variables);
}
