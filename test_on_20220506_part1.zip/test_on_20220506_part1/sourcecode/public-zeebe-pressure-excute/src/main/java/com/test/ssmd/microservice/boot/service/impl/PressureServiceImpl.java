package com.test.ssmd.microservice.boot.service.impl;

import com.test.ssmd.boot.exception.BusinessException;
import com.test.ssmd.microservice.boot.dto.req.CreateInstanceReq;
import com.test.ssmd.microservice.boot.dto.resp.CreateInstanceResp;
import com.test.ssmd.microservice.boot.dto.resp.SetVariablesResp;
import com.test.ssmd.microservice.boot.entity.BpmnResource;
import com.test.ssmd.microservice.boot.manager.ZeebeManager;
import com.test.ssmd.microservice.boot.service.PressureService;
import com.test.ssmd.microservice.boot.util.BpmnInstance;
import com.test.ssmd.microservice.boot.constant.ErrorCode;
import io.camunda.zeebe.client.api.response.DeploymentEvent;
import io.camunda.zeebe.client.api.response.ProcessInstanceEvent;
import io.camunda.zeebe.client.api.response.SetVariablesResponse;
import java.io.InputStream;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 * 描述: 脚手架创建的AService实现类
 *
 * @author yimiluo
 * @create 2022-01-07 3:10 下午
 */
@Slf4j
@Service
public class PressureServiceImpl implements PressureService {

    @Autowired
    private ZeebeManager zeebeManager;

    @Override
    public CreateInstanceResp createInstance(CreateInstanceReq createInstanceReq) {

        final String processId = createInstanceReq.getProcessId();
        final Map<String, Object> variables = createInstanceReq.getVariables();
        final Integer version = createInstanceReq.getVersion();

        try {
            final ProcessInstanceEvent processInstanceEvent =
                    zeebeManager.sendZeebeCreateInstanceCmd(processId, variables, version);
            final long instanceId = processInstanceEvent.getProcessInstanceKey();
            log.info("create instance success, instance id is = {}, process id is {}", instanceId, processId);
            return new CreateInstanceResp(processId, instanceId);
        } catch (Exception e) {
            log.error("createInstance fail!");
            return null;
        }
    }

    @Override
    public DeploymentEvent deployProcess(MultipartFile file) {
        try {
            final BpmnResource bpmnResource = tryGetBpmnResource(file);
            final DeploymentEvent deploymentEvent = zeebeManager.sendZeebeDeployBpmnCmd(bpmnResource);
            log.info("deploymentEvent = {}", deploymentEvent);
            return deploymentEvent;
        } catch (Exception e) {
            log.error("deployProcess fail,msg={}",e.getMessage());
            return null;
        }
    }

    @Override
    public SetVariablesResp setVariables(long elementId, Map<String, Object> variables) {
        try {
            SetVariablesResponse setVariablesResponse = zeebeManager.setVariables(elementId, variables);
            SetVariablesResp setVariablesResp = new SetVariablesResp();
            setVariablesResp.setKey(setVariablesResponse.getKey());
            return setVariablesResp;
        } catch (Exception e) {
            log.error(e.getMessage());
            log.error("setVariables fail!");
            return null;
        }
    }

    private BpmnResource tryGetBpmnResource(MultipartFile bpmnFile) {
        if (bpmnFile == null) {
            throw new BusinessException(ErrorCode.INVALID_PARAMS.getCode(), "bpmn文件不能为空");
        }
        final InputStream inputStream;
        try {
            inputStream = bpmnFile.getInputStream();
        } catch (Exception e) {
            throw new BusinessException(ErrorCode.INVALID_PARAMS.getCode(), "bpmn文件读取异常");
        }
        final BpmnInstance bpmnInstance = new BpmnInstance(inputStream);

        final String bpmnXmlStr = bpmnInstance.toXmlStr();

        final BpmnResource bpmnResource = new BpmnResource();
        bpmnResource.setXmlStr(bpmnXmlStr);
        bpmnResource.setResourceName(String.valueOf(System.currentTimeMillis()));

        return bpmnResource;
    }
}
