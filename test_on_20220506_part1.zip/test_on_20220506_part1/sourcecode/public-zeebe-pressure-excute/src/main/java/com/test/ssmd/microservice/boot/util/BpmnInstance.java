package com.test.ssmd.microservice.boot.util;

import com.test.ssmd.boot.util.CommonUtil;
import io.camunda.zeebe.model.bpmn.Bpmn;
import io.camunda.zeebe.model.bpmn.BpmnModelInstance;
import io.camunda.zeebe.model.bpmn.instance.BaseElement;
import io.camunda.zeebe.model.bpmn.instance.BpmnModelElementInstance;
import io.camunda.zeebe.model.bpmn.instance.FlowNode;
import io.camunda.zeebe.model.bpmn.instance.Process;
import io.camunda.zeebe.model.bpmn.instance.SequenceFlow;
import io.camunda.zeebe.model.bpmn.instance.ServiceTask;
import io.camunda.zeebe.model.bpmn.instance.bpmndi.BpmnEdge;
import io.camunda.zeebe.model.bpmn.instance.bpmndi.BpmnPlane;
import io.camunda.zeebe.model.bpmn.instance.bpmndi.BpmnShape;
import io.camunda.zeebe.model.bpmn.instance.di.Waypoint;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import org.camunda.bpm.model.xml.instance.ModelElementInstance;

/**
 * BPMN流程图实例
 *
 * 基于bpmn-model-api
 * https://docs.camunda.org/manual/latest/user-guide/model-api/bpmn-model-api/
 *
 * 可以对原有的流程图做增强：
 * 1.把ServiceTask的name属性，注入到Job Headers里
 * 2.注入InstanceFinalJob的ServiceTask
 *
 * @author lancetang
 * @date 2021/3/9 19:24
 */
public class BpmnInstance {
    private static final double TASK_DEFAULT_WIDTH = 100;
    private static final double TASK_DEFAULT_HEIGHT = 80;
    private static final double EVENT_DEFAULT_WIDTH = 36;
    private static final double FLOW_DEFAULT_LENGTH = 50;

    private final BpmnModelInstance bpmnModelInstance;

    public BpmnInstance(File file) {
        bpmnModelInstance = Bpmn.readModelFromFile(file);
    }

    public BpmnInstance(InputStream inputStream) {
        bpmnModelInstance = Bpmn.readModelFromStream(inputStream);
    }

    public BpmnInstance(String xmlStr) {
        InputStream inputStream = new ByteArrayInputStream(xmlStr.getBytes(StandardCharsets.UTF_8));
        bpmnModelInstance = Bpmn.readModelFromStream(inputStream);
    }

    protected String generateElementId(String elePrefix) {
        return CommonUtil.generateUniqueId(elePrefix + "_");
    }


    protected <T extends BpmnModelElementInstance> T createElement(BpmnModelElementInstance parentElement,
                                                                   String id,
                                                                   Class<T> elementClass) {
        T element = parentElement.getModelInstance().newInstance(elementClass);
        if (id != null) {
            element.setAttributeValue("id", id, true);
        }
        parentElement.addChildElement(element);
        return element;
    }

    protected SequenceFlow createSequenceFlow(Process process, FlowNode from, FlowNode to) {
        String identifier = generateElementId("Flow");
        SequenceFlow sequenceFlow = createElement(process, identifier, SequenceFlow.class);
        process.addChildElement(sequenceFlow);
        sequenceFlow.setSource(from);
        from.getOutgoing().add(sequenceFlow);
        sequenceFlow.setTarget(to);
        to.getIncoming().add(sequenceFlow);
        return sequenceFlow;
    }

    protected ServiceTask createServiceTask(Process process, String id, String name, String jobType) {
        ServiceTask serviceTask = createElement(process, id, ServiceTask.class);
        return serviceTask.builder()
                .name(name)
                .zeebeJobType(jobType)
                .zeebeJobRetries("0")
                .getElement();

    }

    protected BpmnEdge createBpmnEdge(BpmnPlane bpmnPlane, final BaseElement node, BpmnShape startShape,
                                      BpmnShape endShape) {
        BpmnEdge bpmnEdge = createElement(bpmnPlane, node.getId() + "_di", BpmnEdge.class);
        bpmnEdge.setBpmnElement(node);
        Waypoint startPoint = createElement(bpmnEdge, null, Waypoint.class);
        startPoint.setX(startShape.getBounds().getX() + startShape.getBounds().getWidth() / 2);
        startPoint.setY(startShape.getBounds().getY() + startShape.getBounds().getHeight());
        Waypoint endPoint = createElement(bpmnEdge, null, Waypoint.class);
        endPoint.setX(endShape.getBounds().getX() + endShape.getBounds().getWidth() / 2);
        endPoint.setY(endShape.getBounds().getY());
        return bpmnEdge;
    }

    protected <T extends ModelElementInstance> T findOneElementByType(Class<T> referencingClass) {
        return bpmnModelInstance.getModelElementsByType(referencingClass).iterator().next();
    }

    protected BpmnShape findBpmnShape(final BaseElement node) {
        final Collection<BpmnShape> allShapes = bpmnModelInstance.getModelElementsByType(BpmnShape.class);
        for (BpmnShape shape : allShapes) {
            if (shape.getBpmnElement().equals(node)) {
                return shape;
            }
        }
        return null;
    }

    public String toXmlStr() {
        Bpmn.validateModel(bpmnModelInstance);
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        Bpmn.writeModelToStream(stream, bpmnModelInstance);
        String result = stream.toString(StandardCharsets.UTF_8);
        try {
            stream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

}
